<?php
   define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT']);

   //DataBase Information
   define('DB_NAME', '');
   define('DB_HOST', '');
   define('DB_USERNAME', '');
   define('DB_PASSWORD', '');

   //SendGrid Information
   define('SD_USERNAME', '');
   define('SD_PASSWORD', '');
